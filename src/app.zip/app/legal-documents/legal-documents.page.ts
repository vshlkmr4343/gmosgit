import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-legal-documents',
  templateUrl: './legal-documents.page.html',
  styleUrls: ['./legal-documents.page.scss'],
})
export class LegalDocumentsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
