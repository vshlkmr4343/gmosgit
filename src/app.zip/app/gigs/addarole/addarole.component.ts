import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addarole',
  templateUrl: './addarole.component.html',
  styleUrls: ['./addarole.component.scss'],
})
export class AddaroleComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
