import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-artist-profile',
  templateUrl: './artist-profile.component.html',
  styleUrls: ['./artist-profile.component.scss'],
})
export class ArtistProfileComponent implements OnInit {
  constructor() { }
  ngOnInit() {}
  show(url){

  }

}
