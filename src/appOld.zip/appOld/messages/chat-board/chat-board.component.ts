import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-board',
  templateUrl: './chat-board.component.html',
  styleUrls: ['./chat-board.component.scss'],
})
export class ChatBoardComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
